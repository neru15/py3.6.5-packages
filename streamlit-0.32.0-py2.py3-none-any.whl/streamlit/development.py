"""Variables for dev purposes.

The main purpose of this module (right now at least) is to avoid a dependency
cycle between streamlit.config and streamlit.logger.
"""

is_development_mode = False
