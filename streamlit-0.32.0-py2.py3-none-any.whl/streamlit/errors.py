# Copyright 2018 Streamlit Inc. All rights reserved.

class NoStaticFiles(Exception):
    pass

class S3NoCredentials(Exception):
    pass
